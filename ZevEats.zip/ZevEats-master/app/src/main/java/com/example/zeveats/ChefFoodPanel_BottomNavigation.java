package com.example.zeveats;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ChefFoodPanel_BottomNavigation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chef_food_panel_bottom_navigation);
    }
}